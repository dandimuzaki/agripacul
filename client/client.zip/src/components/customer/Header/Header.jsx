import React, { useEffect, useState } from 'react';
import logo from '../../../assets/logo.png';
import { ArrowDropDown, EmailOutlined, NotificationsOutlined, Person2, Person2Outlined } from '@mui/icons-material';
import './Header.css';
import { Link, useLocation } from 'react-router-dom';
import SearchBar from '../../common/SearchBar/SearchBar';
import CartButton from '../../common/CartButton/CartButton';

const Header = ({ cart }) => {
  const location = useLocation();
  const isCategoryPage = ['/', '/vegetables', '/flowers', '/tools', '/salad'].includes(location.pathname);
  const isCheckout = location.pathname === '/checkout';
  const isAdmin = ['/admin', '/signup', '/login'].includes(location.pathname);

  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const offset = window.scrollY;
      setScrolled(offset > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className={`${isAdmin ? 'hidden' : 'header'} ${isCategoryPage ? '' : 'not-home md:sticky hidden'} ${scrolled ? 'scrolled' : ''}`}    >
      <Link to='/'>
        <div className='hidden cursor-pointer md:flex md:h-8 md:mr-2 items-center'>
          <img className='h-full' src={logo} />
        </div>
      </Link>
      <nav className={`${isCheckout ? 'hidden' : 'lg:flex'} hidden items-center justify-center gap-2 h-9`}>
        <button className={`font-bold cursor-pointer rounded-full text-white h-full px-4 text-[var(--primary)] ${scrolled ? 'hover:border-white active:bg-[var(--light-grey)] border-[var(--primary)] hover:bg-white hover:text-[var(--primary)] active:border-[var(--light-grey)] active:text-[var(--primary)]':'active:border-[var(--dark-primary)] border-white active:bg-[var(--dark-primary)] active:text-white'}`}>Ideas</button>
        <Link to='/about'>
          <button className={`font-bold cursor-pointer rounded-full text-white h-full px-4 py-2 text-[var(--primary)] ${scrolled ? 'hover:border-white active:bg-[var(--light-grey)] border-[var(--primary)] hover:bg-white hover:text-[var(--primary)] active:border-[var(--light-grey)] active:text-[var(--primary)]':'active:border-[var(--dark-primary)] border-white active:bg-[var(--dark-primary)] active:text-white'}`}>About Us</button>
        </Link>
        <button className={`flex gap-2 items-center justify-center font-bold cursor-pointer rounded-full text-white h-full pl-4 pr-2 text-[var(--primary)] ${scrolled ? 'hover:border-white active:bg-[var(--light-grey)] border-[var(--primary)] hover:bg-white hover:text-[var(--primary)] active:border-[var(--light-grey)] active:text-[var(--primary)]':'active:border-[var(--dark-primary)] border-white active:bg-[var(--dark-primary)] active:text-white'}`}>Explore<ArrowDropDown/></button>
      </nav>
      <div className={isCheckout?'hidden':'gap-2 md:flex-row md:flex flex-1'}>
        <div className="flex gap-3 flex-1">
          <SearchBar placeholder="Find fresh vegetables and foods here" />
          <CartButton cart={cart} />
        </div>

        <div className="hidden lg:flex items-center justify-center h-9 gap-2">
          <button className='btn-icon'><EmailOutlined /></button>
          <button className='btn-icon'><NotificationsOutlined /></button>
        </div>
        <div className="hidden md:flex items-center justify-center h-9 gap-2">
          <Link to='/signup'>
            <button className={`shrink-0 font-bold cursor-pointer rounded-full h-full px-4 bg-[var(--primary)] ${scrolled ? 'bg-white text-[var(--primary) active:bg-[var(--light-grey)] text-[var(--primary)]':'text-white active:bg-[var(--dark-primary)]'}`}>Sign Up</button>
          </Link>
          <Link to='/login'>
            <button className={`shrink-0 font-bold cursor-pointer border-2 rounded-full text-white h-full px-4 text-[var(--primary)] ${scrolled ? 'hover:border-white active:bg-[var(--light-grey)] border-[var(--primary)] hover:bg-white hover:text-[var(--primary)] active:border-[var(--light-grey)] active:text-[var(--primary)]':'active:border-[var(--dark-primary)] border-white active:bg-[var(--dark-primary)] active:text-white'}`}>Log In</button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Header;
