import React from 'react';

const AdminHeader = () => {
  return (
    <div className='bg-white w-full'>
      <div className='text-sm'>Home Product </div>
    </div>
  );
};

export default AdminHeader;
