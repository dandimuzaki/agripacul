import React from 'react';

const AddProduct = () => {
  return (
    <div className='bg-black opacity-50'>

    </div>
  );
};

export default AddProduct;
