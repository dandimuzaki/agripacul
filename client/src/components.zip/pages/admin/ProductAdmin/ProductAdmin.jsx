import './ProductAdmin.css';
import React from 'react';
import NavBar from '../../../components/common/NavBar/NavBar';

const ProductAdmin = () => {
  return (
    <div>
      <NavBar />
    </div>
  );
};

export default ProductAdmin;
